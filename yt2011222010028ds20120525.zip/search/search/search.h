#include "stdafx.h"
#include<iostream>
using namespace std;

#ifndef __search_all
#define __search_all

int search_start_auto();
int search_start_sx(char* stun,int times);
int search_start_ef(char* stun,int times);
int search_start_ex(char* stun,int times);
int search_start_hash(char* stun,int times);
int search_start_db(char* stun,int times);
#endif

#ifndef __add_data
#define __add_data

int add_manual();
int add_auto();
int add_default();

#endif

#ifndef __menu
#define __menu

int menu_main();
int menu_adddata();
int menu_search();
int clean_db();

#endif

#ifndef __db
#define __db

int creatdb(const char* dbname);
int sql(char* sqlquery);
struct sqlresult{
	char** result;
	int rownum;
	int colnum;
};
sqlresult sql2(char* sqlquery);
int sqlget(void* aaa,int bbb,char* ccc[],char* ddd[]);
#endif

#ifndef __stu_struct
#define __stu_struct
struct students
{
	char StuNum[14];	//2011224080006 
	char StuName[10];	//����
	char Gender[2];	//��bŮg
};
int s_search_sx(int method,char* value,int times);
struct yxtable{
	students stu;
	int tablelen;
};
int s_search_ef(int method,char* value,int times);
int ef_search(int method,char* value,students* stu_sx,int maxc,int beginn,int endn);
void StartCounter();
double GetCounter();
struct Element{
	char    key[8]; 
    students val;
    int stat;  
	Element* next;
}; 
class MyList
{
    public:
    MyList(int n);
    ~MyList();
    
    public:
    void SetKey2(char* key,students val,Element* nowelem);
	void SetKey(char* key,students val);
    Element SearchKey(char* key);
    int GetMapSize();
    void ShowList();
    Element SearchKey2(char* key,Element* nowelem);
    private:
    Element *elem;
    int     hash_size;
    int     dataNum;
};
int s_search_hash(int method,char* value,int times);
struct tree
{
    students data;
    tree *lchild,*rchild;
    tree *father;
};
int s_search_ex(int method,char* value,int times);
tree* set_tree(tree *root,students p);
void search_tree(tree *root,char* val);
int s_search_db(int method,char* value,int times);
#endif